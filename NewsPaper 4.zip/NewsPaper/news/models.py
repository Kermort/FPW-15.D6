from django.db import models
from django.db.models.deletion import CASCADE
from django.db.models.fields.related import ForeignKey  # импорт
from django.contrib.auth.models import User
from django.db.models import Sum

# class Staff(models.Model):
#     full_name = models.CharField(max_length = 255)
#     position = models.CharField(max_length = 255)
#     labor_contract = models.IntegerField()

# class Product(models.Model):
#     name = models.CharField(max_length = 255)
#     price = models.FloatField(default = 0.0)
#     composition = models.TextField(default = "Состав не указан")

# class Order(models.Model):
#     time_in = models.DateTimeField(auto_now_add = True)
#     time_out = models.DateTimeField(null = True)
#     cost = models.FloatField(default = 0.0)
#     take_away = models.BooleanField(default = False)
#     complete = models.BooleanField(default = False)
#     staff = models.ForeignKey(Staff, on_delete = models.CASCADE)
    
#     products = models.ManyToManyField(Product, through = 'ProductOrder')

# class ProductOrder(models.Model):
#     product = models.ForeignKey(Product, on_delete = models.CASCADE)
#     order = models.ForeignKey(Order, on_delete = models.CASCADE)
#     amount = models.IntegerField(default = 1) 

class Author(models.Model):  # наследуемся от класса Model
    au_user = models.OneToOneField(User, on_delete=models.CASCADE)
    rating = models.FloatField(default = 0.0)

    def update_rating(self):
        post_rating = self.post_set.aggregate(postRating=Sum("rating"))
        pRat = 0
        pRat += post_rating.get("postRating")

        comment_rating = self.au_user.comment_set.aggregate(commentRating=Sum("rating"))
        cRat = 0
        cRat += comment_rating.get("commentRating")

        self.rating = pRat * 3 + cRat
        self.save()


class Category(models.Model):
    name = models.CharField(unique=True, max_length=128, default="category")


class Post(models.Model):
    article = "AR"
    news = "NE"
    types = [(article, "статья"),(news, "новость")]

    author = models.ForeignKey(Author, on_delete=CASCADE)    # связь «один ко многим» с моделью Author;
    post_type = models.CharField(choices=types, default=news, max_length=8)    # поле с выбором — «статья» или «новость»;
    create_time = models.DateTimeField(auto_now_add=True)    # автоматически добавляемая дата и время создания;
    category = models.ManyToManyField(Category, through="PostCategory")    # связь «многие ко многим» с моделью Category (с дополнительной моделью PostCategory);
    title = models.CharField(max_length=255, default="заголовок")    # заголовок статьи/новости;
    text = models.TextField(default="текст")    # текст статьи/новости;
    rating = models.IntegerField(default=0)    # рейтинг статьи/новости.

    def get_absolute_url(self):  # добавим абсолютный путь, чтобы после создания нас перебрасывало на страницу с товаром
        return f'/news/{self.id}'

    def like(self):
        self.rating += 1
        self.save()

    def dislike(self):
        self.rating -= 1
        self.save()

    def preview(self):
        return f"{self.text[0:123]}..."

class PostCategory(models.Model):
    
    post = models.ForeignKey(Post, on_delete=CASCADE)    # связь «один ко многим» с моделью Post;
    category = models.ForeignKey(Category, on_delete=CASCADE)    # связь «один ко многим» с моделью Category.


class Comment(models.Model):
    
    comment_post = ForeignKey(Post, on_delete=CASCADE)    # связь «один ко многим» с моделью Post;
    comment_user = models.ForeignKey(User, on_delete=CASCADE)    # связь «один ко многим» с встроенной моделью User (комментарии может оставить любой пользователь, не обязательно автор);
    text = models.TextField()    # текст комментария;
    create_time = models.DateTimeField(auto_now_add=True)    # дата и время создания комментария;
    rating = models.IntegerField(default=0)    # рейтинг комментария.

    def like(self):
        self.rating += 1
        self.save()

    def dislike (self):
        self.rating -= 1
        self.save()

    def preview(self):
        return f"{self.text[0:123]}..."